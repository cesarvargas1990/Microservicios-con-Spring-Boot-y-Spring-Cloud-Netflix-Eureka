package com.formacionbdi.springboot.app.zuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioZuulServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
